<?php
$db_config = array(
	'host' => 'localhost',
	'user' => 'root',
	'pass' => 'SWEET@mother105',
	'name' => 'fastplus2'
);
